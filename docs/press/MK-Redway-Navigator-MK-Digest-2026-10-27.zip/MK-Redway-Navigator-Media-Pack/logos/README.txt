MK Redway Navigator — logo files

mk-redway-navigator-logo.svg — unchanged production logo, 512 × 512 viewBox.
The SVG contains the approved 1254 × 1254 PNG artwork; it is not a fully vector original.
mk-redway-navigator-logo-1024.png — 1024 × 1024 transparent PNG rendered faithfully from that SVG.
mk-redway-navigator-app-icon-512.png — unchanged approved 512 × 512 transparent app icon.

App brand red: #A9251D. Keep the artwork square and preserve its colours and proportions.
Suggested credit: MK Redway Navigator.
MK Redway Navigator is an independent project; no council endorsement is claimed.
